package mctmods.immersivetechnology.common.blocks.metal.tileentities;

import javax.annotation.Nonnull;

import mctmods.immersivetechnology.common.Config.ITConfig.Settings;
import mctmods.immersivetechnology.common.shared.tileentities.TileEntityCommonOSD;
import mctmods.immersivetechnology.common.shared.ITrashCanBounds;
import mctmods.immersivetechnology.common.util.TranslationKey;

import net.minecraft.util.EnumFacing;

import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;

public class TileEntityTrashEnergy extends TileEntityCommonOSD implements IEnergyStorage, ITrashCanBounds {

    @Override public boolean hasCapability(@Nonnull Capability<?> capability, EnumFacing facing) { return capability == CapabilityEnergy.ENERGY; }

    @SuppressWarnings("unchecked")
    @Override @Nonnull public <T> T getCapability(@Nonnull Capability<T> capability, EnumFacing facing) {
        if (capability == CapabilityEnergy.ENERGY) { return (T)this; }
        return super.getCapability(capability, facing);
    }

    @Override public int receiveEnergy(int maxReceive, boolean simulate) {
        if (!simulate) { acceptedAmount += maxReceive; }
        return maxReceive;
    }

    @Override public int extractEnergy(int maxReceive, boolean simulate) { return 0; }

    @Override public int getEnergyStored() { return 0; }

    @Override public int getMaxEnergyStored() { return Integer.MAX_VALUE; }

    @Override public boolean canExtract() { return false; }

    @Override public boolean canReceive() { return true; }

    @Override public TranslationKey text() {
        return Settings.experimental.per_tick_trash_cans ?
                TranslationKey.OVERLAY_OSD_TRASH_ENERGY_NORMAL_ALTERNATIVE :
                TranslationKey.OVERLAY_OSD_TRASH_ENERGY_NORMAL_FIRST_LINE;
    }
}
