package mctmods.immersivetechnology.common.blocks.metal.tileentities;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import mctmods.immersivetechnology.common.Config.ITConfig.Settings;
import mctmods.immersivetechnology.common.shared.tileentities.TileEntityCommonOSD;
import mctmods.immersivetechnology.common.shared.ITrashCanBounds;
import mctmods.immersivetechnology.common.util.TranslationKey;

import net.minecraft.util.EnumFacing;

import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidTankInfo;
import net.minecraftforge.fluids.IFluidTank;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.FluidTankProperties;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.IFluidTankProperties;

public class TileEntityTrashFluid extends TileEntityCommonOSD implements IFluidTank, IFluidHandler, ITrashCanBounds {

    FluidTankInfo info = new FluidTankInfo(null, Integer.MAX_VALUE);
    IFluidTankProperties[] tank = new IFluidTankProperties[] { new FluidTankProperties(null, Integer.MAX_VALUE, true, false) };

    @Override public boolean hasCapability(@Nonnull Capability<?> capability, EnumFacing facing) { return capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY; }

    @SuppressWarnings("unchecked")
    @Override @Nonnull public <T> T getCapability(@Nonnull Capability<T> capability, EnumFacing facing) {
        if (capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY) { return (T)this; }
        return super.getCapability(capability, facing);
    }

    @Override public FluidStack getFluid() { return null; }

    @Override public int getFluidAmount() { return 0; }

    @Override public int getCapacity() { return Integer.MAX_VALUE; }

    @Override public FluidTankInfo getInfo() { return info; }

    @Override public IFluidTankProperties[] getTankProperties() { return tank; }

    @Override public int fill(FluidStack resource, boolean doFill) {
        if (doFill) { acceptedAmount += resource.amount; }
        return resource.amount;
    }

    @Nullable @Override public FluidStack drain(FluidStack fluidStack, boolean b) { return null; }

    @Override public FluidStack drain(int maxDrain, boolean doDrain) { return null; }

    @Override public TranslationKey text() {
        return Settings.experimental.per_tick_trash_cans ?
                TranslationKey.OVERLAY_OSD_TRASH_FLUID_NORMAL_ALTERNATIVE :
                TranslationKey.OVERLAY_OSD_TRASH_FLUID_NORMAL_FIRST_LINE;
    }
}
