package mctmods.immersivetechnology.common.util.compat.jei;

import mctmods.immersivetechnology.common.Config.ITConfig.Multiblocks;
import mctmods.immersivetechnology.common.ITContent;
import mctmods.immersivetechnology.common.multiblocks.metal.types.BlockType_MetalMultiblock;
import mctmods.immersivetechnology.common.multiblocks.metal.types.BlockType_MetalMultiblock1;
import mctmods.immersivetechnology.common.multiblocks.stone.types.BlockType_StoneMultiblock;

import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class GenericMultiblockIngredient {
    public static List<GenericMultiblockIngredient> list = new ArrayList<>();

    public static GenericMultiblockIngredient STEAM_TURBINE;
    public static GenericMultiblockIngredient DISTILLER;
    public static GenericMultiblockIngredient SOLAR_TOWER;
    public static GenericMultiblockIngredient BOILER;
    public static GenericMultiblockIngredient COOLING_TOWER;
    public static GenericMultiblockIngredient GAS_TURBINE;
    public static GenericMultiblockIngredient HEAT_EXCHANGER;
    public static GenericMultiblockIngredient HIGH_PRESSURE_STEAM_TURBINE;
    public static GenericMultiblockIngredient ELECTROLYTIC_CRUCIBLE_BATTERY;
    public static GenericMultiblockIngredient MELTING_CRUCIBLE;
    public static GenericMultiblockIngredient RADIATOR;
    public static GenericMultiblockIngredient SOLAR_MELTER;
    public static GenericMultiblockIngredient ADVANCED_COKE_OVEN;

    static {
        if (Multiblocks.JEI.enableJEIMultiblocks) {
            if (Multiblocks.enable.enable_steamTurbine) STEAM_TURBINE = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock, 1, BlockType_MetalMultiblock.STEAM_TURBINE.getMeta()));
            if (Multiblocks.enable.enable_distiller) DISTILLER = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock, 1, BlockType_MetalMultiblock.DISTILLER.getMeta()));
            if (Multiblocks.enable.enable_solarTower) SOLAR_TOWER = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock, 1, BlockType_MetalMultiblock.SOLAR_TOWER.getMeta()));
            if (Multiblocks.enable.enable_boiler) BOILER = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock, 1, BlockType_MetalMultiblock.BOILER.getMeta()));
            if (Multiblocks.enable.enable_coolingTower) COOLING_TOWER = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock, 1, BlockType_MetalMultiblock.COOLING_TOWER.getMeta()));
            if (Multiblocks.enable.enable_gasTurbine) GAS_TURBINE = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock1, 1, BlockType_MetalMultiblock1.GAS_TURBINE.getMeta()));
            if (Multiblocks.enable.enable_heatExchanger) HEAT_EXCHANGER = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock1, 1, BlockType_MetalMultiblock1.HEAT_EXCHANGER.getMeta()));
            if (Multiblocks.enable.enable_highPressureSteamTurbine) HIGH_PRESSURE_STEAM_TURBINE = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock1, 1, BlockType_MetalMultiblock1.HIGH_PRESSURE_STEAM_TURBINE.getMeta()));
            if (Multiblocks.enable.enable_electrolyticCrucibleBattery) ELECTROLYTIC_CRUCIBLE_BATTERY = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock1, 1, BlockType_MetalMultiblock1.ELECTROLYTIC_CRUCIBLE_BATTERY.getMeta()));
            if (Multiblocks.enable.enable_meltingCrucible) MELTING_CRUCIBLE = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock1, 1, BlockType_MetalMultiblock1.MELTING_CRUCIBLE.getMeta()));
            if (Multiblocks.enable.enable_radiator) RADIATOR = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock1, 1, BlockType_MetalMultiblock1.RADIATOR.getMeta()));
            if (Multiblocks.enable.enable_solarMelter) SOLAR_MELTER = new GenericMultiblockIngredient(new ItemStack(ITContent.blockMetalMultiblock1, 1, BlockType_MetalMultiblock1.SOLAR_MELTER.getMeta()));
            if (Multiblocks.enable.enable_advancedCokeOven) ADVANCED_COKE_OVEN = new GenericMultiblockIngredient(new ItemStack(ITContent.blockStoneMultiblock, 1, BlockType_StoneMultiblock.ADVANCED_COKE_OVEN.getMeta()));
        }
    }

    public ItemStack renderStack;

    public GenericMultiblockIngredient(ItemStack renderStack) {
        this.renderStack = renderStack;
        list.add(this);
    }
}
