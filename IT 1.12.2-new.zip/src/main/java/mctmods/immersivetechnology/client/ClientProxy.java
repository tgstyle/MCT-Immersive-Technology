package mctmods.immersivetechnology.client;

import blusunrize.immersiveengineering.api.IEApi;
import blusunrize.immersiveengineering.api.ManualHelper;
import blusunrize.immersiveengineering.api.ManualPageMultiblock;
import blusunrize.immersiveengineering.api.energy.wires.WireApi;
import blusunrize.immersiveengineering.client.ClientUtils;
import blusunrize.immersiveengineering.client.IECustomStateMapper;
import blusunrize.immersiveengineering.client.models.obj.IEOBJLoader;
import blusunrize.immersiveengineering.common.IEContent;
import blusunrize.immersiveengineering.common.blocks.IEBlockInterfaces.IGuiTile;
import blusunrize.immersiveengineering.common.blocks.IEBlockInterfaces.IIEMetaBlock;
import blusunrize.immersiveengineering.common.items.ItemEarmuffs;
import blusunrize.immersiveengineering.common.util.ItemNBTHelper;
import blusunrize.lib.manual.ManualPages;

import mctmods.immersivetechnology.ImmersiveTechnology;
import mctmods.immersivetechnology.api.ITGUI;
import mctmods.immersivetechnology.client.event.ClientEventHandler;
import mctmods.immersivetechnology.client.gui.*;
import mctmods.immersivetechnology.client.models.ModelConfigurableSides;
import mctmods.immersivetechnology.client.render.fluid.TileRenderBarrelOpen;
import mctmods.immersivetechnology.client.render.multiblock.*;
import mctmods.immersivetechnology.client.render.multiblock.withanimation.TileRenderHighPressureSteamTurbine;
import mctmods.immersivetechnology.client.render.animation.TileRenderSolarReflector;
import mctmods.immersivetechnology.client.render.multiblock.withanimation.TileRenderSteamTurbine;
import mctmods.immersivetechnology.client.render.multiblock.withanimation.TileRendererGasTurbine;
import mctmods.immersivetechnology.client.render.fluid.TileRenderSteelSheetmetalTank;
import mctmods.immersivetechnology.client.render.animation.TileRenderAdvancedCokeOvenBaseheater;
import mctmods.immersivetechnology.common.CommonProxy;
import mctmods.immersivetechnology.common.Config.ITConfig.Multiblocks;
import mctmods.immersivetechnology.common.ITContent;
import mctmods.immersivetechnology.common.blocks.BlockITFluid;
import mctmods.immersivetechnology.common.blocks.BlockValve.BlockType_Valve;
import mctmods.immersivetechnology.common.blocks.connectors.tileentities.TileEntityTimer;
import mctmods.immersivetechnology.common.blocks.connectors.types.BlockType_Connectors;
import mctmods.immersivetechnology.common.blocks.metal.tileentities.TileEntityBarrelOpen;
import mctmods.immersivetechnology.common.blocks.metal.tileentities.TileEntityFluidValve;
import mctmods.immersivetechnology.common.blocks.metal.tileentities.TileEntityLoadController;
import mctmods.immersivetechnology.common.blocks.metal.tileentities.TileEntityStackLimiter;
import mctmods.immersivetechnology.common.blocks.metal.tileentities.TileEntityTrashItem;
import mctmods.immersivetechnology.common.blocks.metal.tileentities.TileEntityAdvancedCokeOvenBaseheater;
import mctmods.immersivetechnology.common.blocks.metal.types.BlockType_MetalBarrel;
import mctmods.immersivetechnology.common.blocks.metal.types.BlockType_MetalDevice;
import mctmods.immersivetechnology.common.items.ItemITBase;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentities.*;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartAlternator;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartBoiler;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartCoolingTower;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartDistiller;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartElectrolyticCrucibleBattery;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartGasTurbine;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartHeatExchanger;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartHighPressureSteamTurbine;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartMeltingCrucible;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartRadiator;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartSolarMelter;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartSolarReflector;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartSolarTower;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartSteamTurbine;
import mctmods.immersivetechnology.common.multiblocks.metal.tileentitiesmultiblockpart.TileEntityITMultiblockPartSteelSheetmetalTank;
import mctmods.immersivetechnology.common.multiblocks.stone.tileentities.TileEntityAdvancedCokeOvenMaster;
import mctmods.immersivetechnology.common.multiblocks.stone.tileentitiesmultiblockpart.TileEntityITMultiblockPartAdvancedCokeOven;
import mctmods.immersivetechnology.common.util.ITLogger;
import mctmods.immersivetechnology.common.util.ITUtils;
import mctmods.immersivetechnology.common.util.network.BinaryMessageTileSync;
import mctmods.immersivetechnology.common.util.network.MessageStopSound;
import mctmods.immersivetechnology.common.util.network.MessageTileSync;
import mctmods.immersivetechnology.common.util.sound.ITSoundHandler;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.ItemMeshDefinition;
import net.minecraft.client.renderer.block.model.ModelBakery;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.block.statemap.StateMapperBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.model.ModelLoaderRegistry;
import net.minecraftforge.client.model.obj.OBJLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import net.minecraftforge.fml.relauncher.Side;

import javax.annotation.Nonnull;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

@Mod.EventBusSubscriber(modid = ImmersiveTechnology.MODID, value = Side.CLIENT)
public class ClientProxy extends CommonProxy {
    public static final String CAT_POWER = "it_power";
    public static final String CAT_IT = "it";

    @Override public void preInit() {
        ClientUtils.mc().getFramebuffer().enableStencil();
        ModelLoaderRegistry.registerLoader(IEOBJLoader.instance);
        OBJLoader.INSTANCE.addDomain(ImmersiveTechnology.MODID);
        IEOBJLoader.instance.addDomain(ImmersiveTechnology.MODID);
        MinecraftForge.EVENT_BUS.register(this);
        ModelLoaderRegistry.registerLoader(new ModelConfigurableSides.Loader());
    }

    @SubscribeEvent public void PlayerChangedDimensions(PlayerEvent.PlayerChangedDimensionEvent e) { ITSoundHandler.DeleteAllSounds(); }

    @SubscribeEvent public void PlayerLeftSession(PlayerEvent.PlayerLoggedOutEvent e) { ITSoundHandler.DeleteAllSounds(); }

    @SubscribeEvent public void PlayerDisconnected(FMLNetworkEvent.ClientDisconnectionFromServerEvent e) { ITSoundHandler.DeleteAllSounds(); }

    @SubscribeEvent public void onClientWorldUnload(WorldEvent.Unload event) {
        if (event.getWorld().isRemote) { TileRenderITMultiblockStatic.clearAll(); }
    }

    @SubscribeEvent public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            if (!ITUtils.REMOVE_FROM_TICKING.isEmpty()) {
                World world = Minecraft.getMinecraft().world;
                if (world == null) { ITLogger.warn("ClientProxy has tried to access null world! This shouldn't normally happen..."); }
                else {
                    Set<TileEntity> forThisWorld = new HashSet<>();
                    for (TileEntity te : ITUtils.REMOVE_FROM_TICKING) {
                        if (te.getWorld() == world) { forThisWorld.add(te); }
                    }
                    if (!forThisWorld.isEmpty()) {
                        world.tickableTileEntities.removeAll(forThisWorld);
                        ITUtils.REMOVE_FROM_TICKING.removeAll(forThisWorld);
                    }
                }
            }
            calculateVolume();
        }
    }

    public static float volumeAdjustment = 1;

    public void calculateVolume() {
        float prevVolume = volumeAdjustment;
        EntityPlayerSP player = ClientUtils.mc().player;
        if (player == null) { return; }
        ItemStack stack = player.getItemStackFromSlot(EntityEquipmentSlot.HEAD);
        if (!stack.isEmpty()) {
            if (IEContent.itemEarmuffs.equals(stack.getItem())) { volumeAdjustment = ItemEarmuffs.getVolumeMod(stack); }
            else if (ItemNBTHelper.hasKey(stack, "IE:Earmuffs")) {
                stack = ItemNBTHelper.getItemStack(stack, "IE:Earmuffs");
                if (!stack.isEmpty() && IEContent.itemEarmuffs.equals(stack.getItem())) { volumeAdjustment = ItemEarmuffs.getVolumeMod(stack); }
                else { volumeAdjustment = 1; }
            }
            else { volumeAdjustment = 1; }
        }
        else { volumeAdjustment = 1; }
        if (prevVolume != volumeAdjustment) { ITSoundHandler.UpdateAllVolumes(); }
    }

    @SuppressWarnings("deprecation")
    @SubscribeEvent public static void registerModels(ModelRegistryEvent evt) {
        WireApi.registerConnectorForRender("conn_timer", new ResourceLocation("immersivetech:block/connector/connectors_timer.obj.ie"), null);
        WireApi.registerConnectorForRender("conn_con_net", new ResourceLocation("immersivetech:block/connector/connectors_con_net.obj.ie"), null);
        for (Block block : ITContent.registeredITBlocks) {
            final ResourceLocation loc = Block.REGISTRY.getNameForObject(block);
            Item blockItem = Item.getItemFromBlock(block);
            if (block instanceof IIEMetaBlock) {
                IIEMetaBlock ieMetaBlock = (IIEMetaBlock)block;
                if (ieMetaBlock.useCustomStateMapper()) { ModelLoader.setCustomStateMapper(block, IECustomStateMapper.getStateMapper(ieMetaBlock)); }
                ModelLoader.setCustomMeshDefinition(blockItem, stack -> new ModelResourceLocation(loc, "inventory"));
                for (int meta = 0; meta < ieMetaBlock.getMetaEnums().length; meta++) {
                    String location = loc.toString();
                    String prop = ieMetaBlock.appendPropertiesToState() ? ("inventory," + ieMetaBlock.getMetaProperty().getName() + "=" + ieMetaBlock.getMetaEnums()[meta].toString().toLowerCase(Locale.US)) : null;
                    if (ieMetaBlock.useCustomStateMapper()) {
                        String custom = ieMetaBlock.getCustomStateMapping(meta, true);
                        location += "_" + custom;
                    }
                    try { ModelLoader.setCustomModelResourceLocation(blockItem, meta, new ModelResourceLocation(location, prop)); }
                    catch (NullPointerException npe) { throw new RuntimeException("WELP! apparently " + ieMetaBlock + " lacks an item!", npe); }
                }
            }
            else if (block instanceof BlockITFluid) { mapFluidState(block, ((BlockITFluid)block).getFluid()); }
            else { ModelLoader.setCustomModelResourceLocation(blockItem, 0, new ModelResourceLocation(loc, "inventory")); }
        }
        for (Item item : ITContent.registeredITItems) {
            if (item instanceof ItemBlock) { continue; }
            if (item instanceof ItemITBase) {
                ItemITBase ipMetaItem = (ItemITBase)item;
                if (ipMetaItem.registerSubModels && ipMetaItem.getSubNames() != null && ipMetaItem.getSubNames().length > 0) {
                    for (int meta = 0; meta < ipMetaItem.getSubNames().length; meta++) {
                        ResourceLocation loc = new ResourceLocation(ImmersiveTechnology.MODID, ipMetaItem.itemName + "/" + ipMetaItem.getSubNames()[meta]);
                        ModelBakery.registerItemVariants(ipMetaItem, loc);
                        ModelLoader.setCustomModelResourceLocation(ipMetaItem, meta, new ModelResourceLocation(loc, "inventory"));
                    }
                }
                else {
                    final ResourceLocation loc = new ResourceLocation(ImmersiveTechnology.MODID, ipMetaItem.itemName);
                    ModelBakery.registerItemVariants(ipMetaItem, loc);
                    ModelLoader.setCustomMeshDefinition(ipMetaItem, stack -> new ModelResourceLocation(loc, "inventory"));
                }
            }
            else {
                final ResourceLocation loc = Item.REGISTRY.getNameForObject(item);
                ModelBakery.registerItemVariants(item, loc);
                ModelLoader.setCustomMeshDefinition(item, stack -> {
                    assert loc != null;
                    return new ModelResourceLocation(loc, "inventory");
                });
            }
        }
    }

    @Override
    public void init() {
        MinecraftForge.EVENT_BUS.register(new ClientEventHandler());

        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityAdvancedCokeOvenBaseheater.class, new TileRenderAdvancedCokeOvenBaseheater());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityBarrelOpen.class, new TileRenderBarrelOpen());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityBoilerMaster.class, new TileRenderBoiler());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityCoolingTowerMaster.class, new TileRenderCoolingTower());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityElectrolyticCrucibleBatteryMaster.class, new TileRenderElectrolyticCrucibleBattery());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityGasTurbineMaster.class, new TileRendererGasTurbine());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityHeatExchangerMaster.class, new TileRenderHeatExchanger());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityHighPressureSteamTurbineMaster.class, new TileRenderHighPressureSteamTurbine());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityRadiatorMaster.class, new TileRenderRadiator());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntitySolarMelterMaster.class, new TileRenderSolarMelter());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntitySolarReflectorMaster.class, new TileRenderSolarReflector());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntitySolarTowerMaster.class, new TileRenderSolarTower());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntitySteamTurbineMaster.class, new TileRenderSteamTurbine());
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntitySteelSheetmetalTankMaster.class, new TileRenderSteelSheetmetalTank());

        ImmersiveTechnology.packetHandler.registerMessage(MessageTileSync.HandlerClient.class, MessageTileSync.class, 0, Side.CLIENT);
        ImmersiveTechnology.packetHandler.registerMessage(MessageTileSync.HandlerServer.class, MessageTileSync.class, 0, Side.SERVER);
        ImmersiveTechnology.packetHandler.registerMessage(MessageStopSound.HandlerClient.class, MessageStopSound.class, 1, Side.CLIENT);
        ImmersiveTechnology.packetHandler.registerMessage(BinaryMessageTileSync.HandlerClient.class, BinaryMessageTileSync.class, 3, Side.CLIENT);
        ImmersiveTechnology.packetHandler.registerMessage(BinaryMessageTileSync.HandlerServer.class, BinaryMessageTileSync.class, 3, Side.SERVER);
    }

    @Override public void postInit() {
        if (Multiblocks.enable.enable_advancedCokeOven) {
            ManualHelper.addEntry("advancedCokeOven", CAT_IT,
                    new ManualPageMultiblock(ManualHelper.getManual(), "advancedCokeOven0", TileEntityITMultiblockPartAdvancedCokeOven.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "advancedCokeOven1"),
                    new ManualPages.Crafting(ManualHelper.getManual(), "advancedCokeOven2", new ItemStack(ITContent.blockMetalDevice, 1, BlockType_MetalDevice.ADVANCED_COKE_OVEN_BASEHEATER.getMeta())));
        }
        if (Multiblocks.enable.enable_boiler) {
            ManualHelper.addEntry("boiler", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "boiler0", TileEntityITMultiblockPartBoiler.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "boiler1"),
                    new ManualPages.Text(ManualHelper.getManual(), "boiler2"));
        }
        if (Multiblocks.enable.enable_solarTower) {
            ManualHelper.addEntry("solarTower", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "solarTower0", TileEntityITMultiblockPartSolarTower.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "solarTower1"),
                    new ManualPageMultiblock(ManualHelper.getManual(), "solarTower2", TileEntityITMultiblockPartSolarReflector.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "solarTower3"));
        }
        if (Multiblocks.enable.enable_heatExchanger) {
            ManualHelper.addEntry("heatExchanger", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "heatExchanger0", TileEntityITMultiblockPartHeatExchanger.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "heatExchanger1"));
        }
        if (Multiblocks.enable.enable_gasTurbine || Multiblocks.enable.enable_steamTurbine) {
            ManualHelper.addEntry("alternator", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "alternator0", TileEntityITMultiblockPartAlternator.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "alternator1"),
                    new ManualPages.Image(ManualHelper.getManual(), "alternator2", "immersivetech:textures/misc/alternator.png;0;0;110;50"));
        }
        if (Multiblocks.enable.enable_steamTurbine) {
            ManualHelper.addEntry("steamTurbine", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "steamTurbine0", TileEntityITMultiblockPartSteamTurbine.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "steamTurbine1"),
                    new ManualPages.Text(ManualHelper.getManual(), "steamTurbine2"));
        }
        if (Multiblocks.enable.enable_highPressureSteamTurbine) {
            ManualHelper.addEntry("highPressureSteamTurbine", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "highPressureSteamTurbine0", TileEntityITMultiblockPartHighPressureSteamTurbine.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "highPressureSteamTurbine1"),
                    new ManualPages.Text(ManualHelper.getManual(), "highPressureSteamTurbine2"));
        }
        if (Multiblocks.enable.enable_gasTurbine) {
            ManualHelper.addEntry("gasTurbine", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "gasTurbine0", TileEntityITMultiblockPartGasTurbine.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "gasTurbine1"),
                    new ManualPages.Text(ManualHelper.getManual(), "gasTurbine2"),
                    new ManualPages.Text(ManualHelper.getManual(), "gasTurbine3"));
        }
        if (Multiblocks.enable.enable_coolingTower) {
            ManualHelper.addEntry("coolingTower", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "coolingTower0", TileEntityITMultiblockPartCoolingTower.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "coolingTower1"));
        }
        if (Multiblocks.enable.enable_radiator) {
            ManualHelper.addEntry("radiator", CAT_POWER,
                    new ManualPageMultiblock(ManualHelper.getManual(), "radiator0", TileEntityITMultiblockPartRadiator.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "radiator1"));
        }
        ManualHelper.addEntry("controlBlocks", CAT_IT,
                new ManualPages.Crafting(ManualHelper.getManual(), "controlBlocks0", new ItemStack(ITContent.blockValve, 1, BlockType_Valve.STACK_LIMITER.getMeta())),
                new ManualPages.Crafting(ManualHelper.getManual(), "controlBlocks1", new ItemStack(ITContent.blockValve, 1, BlockType_Valve.LOAD_CONTROLLER.getMeta())),
                new ManualPages.Crafting(ManualHelper.getManual(), "controlBlocks2", new ItemStack(ITContent.blockValve, 1, BlockType_Valve.FLUID_VALVE.getMeta())));
        ManualHelper.addEntry("redstone", CAT_IT,
                new ManualPages.Crafting(ManualHelper.getManual(), "redstone0", new ItemStack(ITContent.blockConnectors, 1, BlockType_Connectors.CONNECTORS_TIMER.getMeta())));
        ManualHelper.addEntry("openBarrel", CAT_IT,
                new ManualPages.Crafting(ManualHelper.getManual(), "openBarrel0", new ItemStack(ITContent.blockMetalBarrel, 1, BlockType_MetalBarrel.BARREL_OPEN.getMeta())));
        ManualHelper.addEntry("steelBarrel", CAT_IT,
                new ManualPages.Crafting(ManualHelper.getManual(), "steelBarrel0", new ItemStack(ITContent.blockMetalBarrel, 2, BlockType_MetalBarrel.BARREL_STEEL.getMeta())));
        ManualHelper.addEntry("steelTank", CAT_IT,
                new ManualPageMultiblock(ManualHelper.getManual(), "steelTank0", TileEntityITMultiblockPartSteelSheetmetalTank.instance),
                new ManualPages.Text(ManualHelper.getManual(), "steelTank1"));
        if (Multiblocks.enable.enable_distiller) {
            ManualHelper.addEntry("distiller", CAT_IT,
                    new ManualPageMultiblock(ManualHelper.getManual(), "distiller0", TileEntityITMultiblockPartDistiller.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "distiller1"));
        }
        if (Multiblocks.enable.enable_meltingCrucible) {
            ManualHelper.addEntry("meltingCrucible", CAT_IT,
                    new ManualPageMultiblock(ManualHelper.getManual(), "meltingCrucible0", TileEntityITMultiblockPartMeltingCrucible.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "meltingCrucible1"));
        }
        if (Multiblocks.enable.enable_solarMelter) {
            ManualHelper.addEntry("solarMelter", CAT_IT,
                    new ManualPageMultiblock(ManualHelper.getManual(), "solarMelter0", TileEntityITMultiblockPartSolarMelter.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "solarMelter1"));
        }
        if (Multiblocks.enable.enable_electrolyticCrucibleBattery) {
            ManualHelper.addEntry("electrolyticCrucibleBattery", CAT_IT,
                    new ManualPageMultiblock(ManualHelper.getManual(), "electrolyticCrucibleBattery0", TileEntityITMultiblockPartElectrolyticCrucibleBattery.instance),
                    new ManualPages.Text(ManualHelper.getManual(), "electrolyticCrucibleBattery1"),
                    new ManualPages.Text(ManualHelper.getManual(), "electrolyticCrucibleBattery2"));
        }
    }

    private static void mapFluidState(Block block, Fluid fluid) {
        Item item = Item.getItemFromBlock(block);
        FluidStateMapper mapper = new FluidStateMapper(fluid);
        if (item != Items.AIR) {
            ModelLoader.registerItemVariants(item);
            ModelLoader.setCustomMeshDefinition(item, mapper);
        }
        ModelLoader.setCustomStateMapper(block, mapper);
    }

    static class FluidStateMapper extends StateMapperBase implements ItemMeshDefinition {
        public final ModelResourceLocation location;

        public FluidStateMapper(Fluid fluid) { this.location = new ModelResourceLocation(ImmersiveTechnology.MODID + ":fluid_block", fluid.getName()); }

        @Nonnull @Override protected ModelResourceLocation getModelResourceLocation(@Nonnull IBlockState state) { return location; }

        @Nonnull @Override public ModelResourceLocation getModelLocation(@Nonnull ItemStack stack) { return location; }
    }

    static {
        IEApi.renderCacheClearers.add(ModelConfigurableSides.modelCache::clear);
        IEApi.renderCacheClearers.add(TileRenderITMultiblockStatic::clearAll);
    }

    @Override public void clearRenderCaches() {
        for (Runnable r : IEApi.renderCacheClearers) { r.run(); }
    }

    @Override public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        TileEntity tile = world.getTileEntity(new BlockPos(x, y, z));
        if (tile instanceof IGuiTile) {
            if (ID == ITGUI.GUIID_Advanced_coke_oven && tile instanceof TileEntityAdvancedCokeOvenMaster) { return new GuiAdvancedCokeOven(player.inventory, (TileEntityAdvancedCokeOvenMaster)tile); }
            if (ID == ITGUI.GUIID_Boiler && tile instanceof TileEntityBoilerMaster) { return new GuiBoiler(player.inventory, (TileEntityBoilerMaster)tile); }
            if (ID == ITGUI.GUIID_Distiller && tile instanceof TileEntityDistillerMaster) { return new GuiDistiller(player.inventory, (TileEntityDistillerMaster)tile); }
            if (ID == ITGUI.GUIID_Fluid_Valve && tile instanceof TileEntityFluidValve) { return new GuiFluidValve((TileEntityFluidValve)tile); }
            if (ID == ITGUI.GUIID_Load_Controller && tile instanceof TileEntityLoadController) { return new GuiLoadController((TileEntityLoadController)tile); }
            if (ID == ITGUI.GUIID_Melting_Crucible && tile instanceof TileEntityMeltingCrucibleMaster) { return new GuiMeltingCrucible(player.inventory, (TileEntityMeltingCrucibleMaster)tile); }
            if (ID == ITGUI.GUIID_Solar_Melter && tile instanceof TileEntitySolarMelterMaster) { return new GuiSolarMelter(player.inventory, (TileEntitySolarMelterMaster)tile); }
            if (ID == ITGUI.GUIID_Solar_Tower && tile instanceof TileEntitySolarTowerMaster) { return new GuiSolarTower(player.inventory, (TileEntitySolarTowerMaster)tile); }
            if (ID == ITGUI.GUIID_Stack_Limiter && tile instanceof TileEntityStackLimiter) { return new GuiStackLimiter((TileEntityStackLimiter)tile); }
            if (ID == ITGUI.GUIID_Timer && tile instanceof TileEntityTimer) { return new GuiTimer(player.inventory, (TileEntityTimer)tile); }
            if (ID == ITGUI.GUIID_Trash_Item && tile instanceof TileEntityTrashItem) { return new GuiTrashItem(player.inventory, (TileEntityTrashItem)tile); }
        }
        return null;
    }
}
